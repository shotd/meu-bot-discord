# Bot Discord completo

Inclui:

- 🎫 Tickets com botão e categoria
- 👋 Entrada e saída
- 🛡️ Moderação: links/invites, anti-spam, warns e timeout automático
- 🤖 Slash commands
- 💰 Painel de loja
- 📦 Produtos, estoque e registro de pedidos
- 📊 Logs
- 🎨 Embeds
- 🔘 Botões e menu select
- 🔐 Permissões por Discord + cargo de staff

## 1. Instalar

Tenha Node.js 20+ instalado.

```bash
npm install
```

## 2. Configurar

Copie `.env.example` para `.env` e preencha:

- DISCORD_TOKEN
- CLIENT_ID
- GUILD_ID
- IDs dos canais/categoria/cargo

Nunca publique seu token.

## 3. Criar o bot

No Developer Portal do Discord, crie uma aplicação, adicione um bot e use OAuth2 para instalar no servidor com os escopos `bot` e `applications.commands`.

O bot precisa das permissões adequadas para as funções que você pretende usar, especialmente View Channel, Send Messages, Manage Channels, Manage Messages, Moderate Members e Manage Roles quando aplicável.

Para a moderação por conteúdo, habilite também o Message Content Intent na página do bot.

## 4. Registrar os comandos

```bash
npm run deploy
```

## 5. Iniciar

```bash
npm start
```

## Comandos

`/ticket` — painel de tickets

`/painel-loja` — painel da loja

`/produto listar` — lista produtos

`/produto adicionar` — cadastra/atualiza produto

`/produto estoque` — altera estoque

`/warn` — advertência

`/clear` — apagar mensagens

`/lock` e `/unlock` — bloquear/desbloquear canal

## Loja

A base registra pedidos, produtos e estoque em `data/database.json`.

Ela não processa pagamentos reais nem entrega automaticamente contas/Nitro. Para isso, conecte um provedor de pagamento e um sistema de entrega que seja compatível com as regras dos serviços vendidos.

## Personalização

Edite os textos, emojis, nomes e embeds em `src/index.js`.
