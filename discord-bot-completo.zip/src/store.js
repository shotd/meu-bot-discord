const fs = require("node:fs");
const path = require("node:path");

const dataDir = path.join(__dirname, "..", "data");
const file = path.join(dataDir, "database.json");

function ensure() {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, JSON.stringify({
      warnings: {},
      products: [
        { id: "nitro", name: "Discord Nitro", price: 20, stock: 0, description: "Produto configurável." },
        { id: "conta", name: "Conta", price: 10, stock: 0, description: "Produto configurável." },
        { id: "produto", name: "Produto personalizado", price: 5, stock: 0, description: "Produto configurável." }
      ],
      orders: []
    }, null, 2));
  }
}
function read() {
  ensure();
  return JSON.parse(fs.readFileSync(file, "utf8"));
}
function write(db) {
  ensure();
  fs.writeFileSync(file, JSON.stringify(db, null, 2));
}
module.exports = { read, write };