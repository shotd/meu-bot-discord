require("dotenv").config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  welcomeChannelId: process.env.WELCOME_CHANNEL_ID,
  goodbyeChannelId: process.env.GOODBYE_CHANNEL_ID,
  logChannelId: process.env.LOG_CHANNEL_ID,
  ticketCategoryId: process.env.TICKET_CATEGORY_ID,
  staffRoleId: process.env.STAFF_ROLE_ID,
  ticketPrefix: process.env.TICKET_NAME_PREFIX || "ticket",
  maxWarnings: Number(process.env.MAX_WARNINGS || 3),
  antiLinks: process.env.ANTI_LINKS !== "false",
  antiInvites: process.env.ANTI_INVITES !== "false",
  antiSpam: process.env.ANTI_SPAM !== "false"
};