const { EmbedBuilder } = require("discord.js");
const config = require("./config");

async function sendLog(guild, title, description) {
  if (!config.logChannelId) return;
  const channel = await guild.channels.fetch(config.logChannelId).catch(() => null);
  if (!channel) return;
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
  await channel.send({ embeds: [embed] }).catch(() => {});
}

function isStaff(member) {
  return member.permissions.has("ManageGuild") ||
    (config.staffRoleId && member.roles.cache.has(config.staffRoleId));
}

module.exports = { sendLog, isStaff };