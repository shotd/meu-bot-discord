const {
  Client, GatewayIntentBits, Partials, Events, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelType, PermissionsBitField, StringSelectMenuBuilder
} = require("discord.js");
const config = require("./config");
const db = require("./store");
const { sendLog, isStaff } = require("./utils");

if (!config.token) throw new Error("DISCORD_TOKEN não configurado.");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

const spamMap = new Map();

client.once(Events.ClientReady, c => {
  console.log(`Online como ${c.user.tag}`);
  c.user.setActivity("tickets | /ticket", { type: 3 });
});

client.on(Events.GuildMemberAdd, async member => {
  if (!config.welcomeChannelId) return;
  const ch = await member.guild.channels.fetch(config.welcomeChannelId).catch(() => null);
  if (!ch) return;
  const embed = new EmbedBuilder()
    .setTitle("👋 Bem-vindo!")
    .setDescription(`Seja bem-vindo(a), ${member}! Você é o membro **#${member.guild.memberCount}**.`)
    .setThumbnail(member.user.displayAvatarURL())
    .setTimestamp();
  await ch.send({ embeds: [embed] }).catch(() => {});
  sendLog(member.guild, "Membro entrou", `${member.user.tag} entrou no servidor.`);
});

client.on(Events.GuildMemberRemove, async member => {
  if (!config.goodbyeChannelId) return;
  const ch = await member.guild.channels.fetch(config.goodbyeChannelId).catch(() => null);
  if (!ch) return;
  const embed = new EmbedBuilder()
    .setTitle("👋 Até logo!")
    .setDescription(`**${member.user.tag}** saiu do servidor.`)
    .setThumbnail(member.user.displayAvatarURL())
    .setTimestamp();
  await ch.send({ embeds: [embed] }).catch(() => {});
  sendLog(member.guild, "Membro saiu", `${member.user.tag} saiu do servidor.`);
});

const badPatterns = [
  /\bdiscord\.gg\/[^\s]+/i,
  /\bdiscord\.com\/invite\/[^\s]+/i,
  /\bhttps?:\/\/[^\s]+/i
];

client.on(Events.MessageCreate, async message => {
  if (!message.guild || message.author.bot || isStaff(message.member)) return;

  if (config.antiLinks && badPatterns.some(r => r.test(message.content))) {
    await message.delete().catch(() => {});
    const warn = await message.channel.send(`${message.author}, links não são permitidos aqui.`);
    setTimeout(() => warn.delete().catch(() => {}), 5000);
    await addWarning(message.member, "Link/invite não permitido");
    return;
  }

  if (config.antiSpam) {
    const now = Date.now();
    const list = spamMap.get(message.author.id) || [];
    const recent = list.filter(t => now - t < 5000);
    recent.push(now);
    spamMap.set(message.author.id, recent);
    if (recent.length >= 6) {
      await message.delete().catch(() => {});
      await addWarning(message.member, "Spam");
      spamMap.set(message.author.id, []);
    }
  }
});

async function addWarning(member, reason) {
  const data = db.read();
  const key = `${member.guild.id}:${member.id}`;
  data.warnings[key] = (data.warnings[key] || 0) + 1;
  const count = data.warnings[key];
  db.write(data);
  await sendLog(member.guild, "⚠️ Advertência", `${member} recebeu uma advertência.\n**Motivo:** ${reason}\n**Total:** ${count}`);

  if (count >= config.maxWarnings) {
    await member.timeout(60 * 60 * 1000, `Limite de advertências: ${reason}`).catch(() => {});
    data.warnings[key] = 0;
    db.write(data);
    await sendLog(member.guild, "⏱️ Timeout automático", `${member} atingiu ${config.maxWarnings} advertências.`);
  }
}

async function openTicket(interaction) {
  const guild = interaction.guild;
  const existing = guild.channels.cache.find(c => c.name === `${config.ticketPrefix}-${interaction.user.id}`);
  if (existing) return interaction.reply({ content: `Você já possui um ticket: ${existing}`, ephemeral: true });

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
  ];
  if (config.staffRoleId) {
    overwrites.push({ id: config.staffRoleId, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] });
  }

  const channel = await guild.channels.create({
    name: `${config.ticketPrefix}-${interaction.user.id}`,
    type: ChannelType.GuildText,
    parent: config.ticketCategoryId || null,
    permissionOverwrites: overwrites
  });

  const embed = new EmbedBuilder()
    .setTitle("🎫 Ticket aberto")
    .setDescription(`Olá ${interaction.user}! Explique seu pedido e aguarde a equipe.\n\nUse o botão abaixo para fechar o ticket.`)
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket_close").setLabel("Fechar ticket").setStyle(ButtonStyle.Danger)
  );

  await channel.send({ content: config.staffRoleId ? `<@&${config.staffRoleId}>` : undefined, embeds: [embed], components: [row] });
  await interaction.reply({ content: `Ticket criado: ${channel}`, ephemeral: true });
  sendLog(guild, "🎫 Ticket aberto", `${interaction.user} abriu ${channel}.`);
}

async function closeTicket(interaction) {
  if (!interaction.channel.name.startsWith(`${config.ticketPrefix}-`)) {
    return interaction.reply({ content: "Este canal não é um ticket.", ephemeral: true });
  }
  if (!isStaff(interaction.member)) {
    return interaction.reply({ content: "Apenas a equipe pode fechar este ticket.", ephemeral: true });
  }
  await interaction.reply("🔒 Ticket será fechado em 5 segundos.");
  sendLog(interaction.guild, "🎫 Ticket fechado", `${interaction.user} fechou ${interaction.channel}.`);
  setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
}

async function sendStorePanel(interaction) {
  const data = db.read();
  const options = data.products.slice(0, 25).map(p => ({
    label: p.name.slice(0, 100),
    value: p.id,
    description: `${p.price.toFixed(2)} | estoque: ${p.stock}`.slice(0, 100)
  }));
  if (!options.length) return interaction.reply({ content: "Nenhum produto cadastrado.", ephemeral: true });

  const embed = new EmbedBuilder()
    .setTitle("🛒 Loja")
    .setDescription("Selecione um produto no menu abaixo. O bot registra o pedido; o pagamento/entrega pode ser integrado depois.")
    .setTimestamp();

  const menu = new StringSelectMenuBuilder()
    .setCustomId("store_select")
    .setPlaceholder("Escolha um produto")
    .addOptions(options);

  await interaction.channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] });
  await interaction.reply({ content: "Painel enviado.", ephemeral: true });
}

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "ticket") {
        const embed = new EmbedBuilder().setTitle("🎫 Atendimento").setDescription("Clique abaixo para abrir um ticket com a equipe.");
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("ticket_open").setLabel("Abrir ticket").setEmoji("🎫").setStyle(ButtonStyle.Primary)
        );
        return interaction.reply({ embeds: [embed], components: [row] });
      }

      if (interaction.commandName === "painel-loja") return sendStorePanel(interaction);

      if (interaction.commandName === "produto") {
        const sub = interaction.options.getSubcommand();
        const data = db.read();

        if (sub === "listar") {
          const text = data.products.map(p => `**${p.name}** — R$ ${p.price.toFixed(2)} — estoque: ${p.stock}\n${p.description || ""}`).join("\n\n") || "Nenhum produto.";
          return interaction.reply({ embeds: [new EmbedBuilder().setTitle("📦 Produtos").setDescription(text)] });
        }
        if (sub === "adicionar") {
          const product = {
            id: interaction.options.getString("id"),
            name: interaction.options.getString("nome"),
            price: interaction.options.getNumber("preco"),
            stock: interaction.options.getInteger("estoque"),
            description: interaction.options.getString("descricao") || ""
          };
          data.products = data.products.filter(p => p.id !== product.id);
          data.products.push(product);
          db.write(data);
          return interaction.reply(`Produto **${product.name}** salvo.`);
        }
        if (sub === "estoque") {
          const id = interaction.options.getString("id");
          const product = data.products.find(p => p.id === id);
          if (!product) return interaction.reply({ content: "Produto não encontrado.", ephemeral: true });
          product.stock = interaction.options.getInteger("quantidade");
          db.write(data);
          return interaction.reply(`Estoque de **${product.name}**: ${product.stock}.`);
        }
      }

      if (interaction.commandName === "warn") {
        const member = interaction.options.getMember("membro");
        const reason = interaction.options.getString("motivo");
        if (!member) return interaction.reply({ content: "Membro não encontrado.", ephemeral: true });
        await addWarning(member, reason);
        return interaction.reply(`⚠️ ${member} recebeu uma advertência: **${reason}**`);
      }

      if (interaction.commandName === "clear") {
        const amount = interaction.options.getInteger("quantidade");
        const deleted = await interaction.channel.bulkDelete(amount, true);
        return interaction.reply({ content: `🧹 ${deleted.size} mensagens apagadas.`, ephemeral: true });
      }

      if (interaction.commandName === "lock" || interaction.commandName === "unlock") {
        const lock = interaction.commandName === "lock";
        await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
          SendMessages: !lock
        });
        return interaction.reply(lock ? "🔒 Canal bloqueado." : "🔓 Canal desbloqueado.");
      }
    }

    if (interaction.isButton()) {
      if (interaction.customId === "ticket_open") return openTicket(interaction);
      if (interaction.customId === "ticket_close") return closeTicket(interaction);
    }

    if (interaction.isStringSelectMenu() && interaction.customId === "store_select") {
      const id = interaction.values[0];
      const data = db.read();
      const product = data.products.find(p => p.id === id);
      if (!product) return interaction.reply({ content: "Produto não encontrado.", ephemeral: true });
      if (product.stock <= 0) return interaction.reply({ content: "Esse produto está sem estoque.", ephemeral: true });

      data.orders.push({
        id: `${Date.now()}`,
        userId: interaction.user.id,
        productId: product.id,
        price: product.price,
        status: "pending",
        createdAt: new Date().toISOString()
      });
      db.write(data);

      const embed = new EmbedBuilder()
        .setTitle("🛍️ Pedido criado")
        .setDescription(`**Produto:** ${product.name}\n**Valor:** R$ ${product.price.toFixed(2)}\n\nPedido registrado como **pendente**. Um membro da equipe pode continuar o atendimento pelo ticket.`)
        .setTimestamp();

      await interaction.reply({ embeds: [embed], ephemeral: true });
      sendLog(interaction.guild, "🛒 Novo pedido", `${interaction.user} pediu **${product.name}** por R$ ${product.price.toFixed(2)}.`);
    }
  } catch (err) {
    console.error(err);
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: "Ocorreu um erro ao executar essa ação.", ephemeral: true }).catch(() => {});
    }
  }
});

client.login(config.token);