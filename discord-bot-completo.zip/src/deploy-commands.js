const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const config = require("./config");

const commands = [
  new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Envia o painel para abrir tickets.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels.bitfield.toString()),

  new SlashCommandBuilder()
    .setName("painel-loja")
    .setDescription("Envia o painel da loja.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.bitfield.toString()),

  new SlashCommandBuilder()
    .setName("produto")
    .setDescription("Gerencia os produtos da loja.")
    .addSubcommand(s => s.setName("listar").setDescription("Lista os produtos"))
    .addSubcommand(s => s.setName("adicionar").setDescription("Adiciona um produto")
      .addStringOption(o => o.setName("id").setDescription("ID interno").setRequired(true))
      .addStringOption(o => o.setName("nome").setDescription("Nome").setRequired(true))
      .addNumberOption(o => o.setName("preco").setDescription("Preço").setRequired(true).setMinValue(0))
      .addIntegerOption(o => o.setName("estoque").setDescription("Estoque").setRequired(true).setMinValue(0))
      .addStringOption(o => o.setName("descricao").setDescription("Descrição").setRequired(false)))
    .addSubcommand(s => s.setName("estoque").setDescription("Altera o estoque")
      .addStringOption(o => o.setName("id").setDescription("ID do produto").setRequired(true))
      .addIntegerOption(o => o.setName("quantidade").setDescription("Novo estoque").setRequired(true).setMinValue(0)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild.bitfield.toString()),

  new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Adverte um membro.")
    .addUserOption(o => o.setName("membro").setDescription("Membro").setRequired(true))
    .addStringOption(o => o.setName("motivo").setDescription("Motivo").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers.bitfield.toString()),

  new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Apaga mensagens.")
    .addIntegerOption(o => o.setName("quantidade").setDescription("1 a 100").setRequired(true).setMinValue(1).setMaxValue(100))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages.bitfield.toString()),

  new SlashCommandBuilder()
    .setName("lock")
    .setDescription("Bloqueia o canal para membros.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels.bitfield.toString()),

  new SlashCommandBuilder()
    .setName("unlock")
    .setDescription("Desbloqueia o canal para membros.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels.bitfield.toString())
].map(c => c.toJSON());

const rest = new REST({ version: "10" }).setToken(config.token);

(async () => {
  if (!config.token || !config.clientId || !config.guildId) {
    throw new Error("Preencha DISCORD_TOKEN, CLIENT_ID e GUILD_ID no .env");
  }
  await rest.put(
    Routes.applicationGuildCommands(config.clientId, config.guildId),
    { body: commands }
  );
  console.log("Comandos registrados no servidor.");
})();